
  # Omegle-like Web App UI

  This is a code bundle for Omegle-like Web App UI. The original project is available at https://www.figma.com/design/ewT7a2r6anmlqAEolxnQxv/Omegle-like-Web-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  